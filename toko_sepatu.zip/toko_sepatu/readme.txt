username for admin
admin ==> username
admin ==> password
 
username for user
dipa ==> username
dipa ==> password



untuk onkir
padang = Rp 20.000
pekanbaru = Rp 25.000 
jambi = Rp 28.000
jakarta = Rp 15.000