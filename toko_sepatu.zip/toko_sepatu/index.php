<script>
    window.location.href='admin/login/index.php';
</script>