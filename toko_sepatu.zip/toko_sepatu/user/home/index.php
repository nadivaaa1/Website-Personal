<main class="site-main">

  <!--================ Hero banner start =================-->
  <section class="dipa">
    <div class="container">
      <div class="row no-gutters align-items-center pt-60px">
        <div class="col-5 d-none d-sm-block">
          <div class="dipa__img">
            <img class="img-fluid" src="assets/img/crocs22.jpg" alt="">
          </div>
        </div>
        <div class="col-sm-7 col-lg-6 offset-lg-1 pl-4 pl-md-5 pl-lg-0">
          <div class="dipa__content">
            <h4>Belanja Menyenangkan</h4>
            <h1>Jelajahi Crocs Menarik yang kami miliki</h1>
            <p>Dengan Kuliatas Brand Import Original yang membuat penampilanmu menjadi semakin menarik</p>
            <a class="button button-hero" href="?page=produk/index">Belanja Sekarang</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--================ Hero banner start =================-->

</main>