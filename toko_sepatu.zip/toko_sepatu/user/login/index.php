<script>
    window.location.href='../../Admin/?page=login/index';
</script>