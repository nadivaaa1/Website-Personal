<?php
session_start();
include "koneksi.php";
include "layout/header.php";
include "content.php";
include "layout/footer.php";
?>