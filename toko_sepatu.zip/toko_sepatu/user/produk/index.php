	    <section class="section-margin--small mb-5">
    <div class="container">
      <div class="row">
        <div class="col-xl-3 col-lg-4 col-md-5">
        </div>
        <div class="col-xl-9 col-lg-8 col-md-7">
          <!-- Start Filter Bar -->

          <!-- End Filter Bar -->
          <!-- Start Best Seller -->
          <section class="lattest-product-area pb-40 category-list">
            <div class="row">
            <?php
      $project = mysqli_query($koneksi, "SELECT * FROM produk JOIN kategori ON produk.id_kategori=kategori.id_kategori ORDER BY id_produk DESC");
      while ($data = mysqli_fetch_array($project)) :
      ?>
              <div class="col-md-2 col-lg-4">
                <div class="card text-center card-product">
                  <div class="card-product__img">
                  <img src="../admin/assets/images/produk/<?= $data['gambar_produk'] ?>" width="100%" height="90%" style="object-fit: cover;" alt="">
                  </div>
                  <div class="card-body">
                    <p><?= $data['nama_kategori'] ?></p>
                    <h4 class="card-product__title"><a href="?page=detail_satu/index&id_produk=<?= $data['id_produk'] ?>"><?= $data['nama_produk'] ?></a></h4>
                    <p class="card-product__price">Rp,<?= number_format($data['harga']) ;?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>`
            </div>
          </section>
          <!-- End Best Seller -->
        </div>
      </div>
    </div>
  </section>
	<!-- ================ category section end ================= -->		  


	<!-- ================ Subscribe section start ================= -->		  
  <section class="subscribe-position">
    <div class="container">
      <div class="subscribe text-center">
        <h3 class="subscribe__title">Dapatkan Penawaran Terbaru Kami</h3>
        <p>Dengan Crocs</p>
        <div id="mc_embed_signup">
          <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe-form form-inline mt-5 pt-1">
            <div class="form-group ml-sm-auto">
              <input class="form-control mb-1" type="email" name="EMAIL" placeholder="Enter your email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '" >
              <div class="info"></div>
            </div>
            <button class="button button-subscribe mr-auto mb-1" type="submit">Subscribe Now</button>
            <div style="position: absolute; left: -5000px;">
              <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
            </div>

          </form>
        </div>
        
      </div>
    </div>
  </section>
	<!-- ================ Subscribe section end ================= -->		  


  <!--================ Start footer Area  =================-->	
