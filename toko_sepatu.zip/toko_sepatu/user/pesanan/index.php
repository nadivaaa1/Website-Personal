


<!--================Checkout Area =================-->
<section class="checkout_area section-margin--small">
    <div class="container">
        <div class="returning_customer">
            <div class="check_title">
                <h2>Returning Customer? <a href="../admin/?page=login/index">Click here to login</a></h2>
            </div>
            <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new
                customer, please proceed to the Billing & Shipping section.</p>

        </div>
        <div class="billing_details">
            <div class="row">
                <div class="col-lg-8">
                    <h3>Billing Details</h3>
                    <form action="pesanan/proses.php" method="post" enctype="multipart/form-data">
                        <div class="col-md-12 form-group">
                            Upload Bukti Bayar
                            <input type="file" class="form-control" id="company" name="bukti_bayar" placeholder="Company name">
                        </div>
                        <div class="col-md-6 form-group p_star">
                            No Tujuan
                            <input type="text" class="form-control" id="number" name="no_tujuan">
                            <span class="placeholder" data-placeholder="Phone number"></span>
                        </div>
                        <div class="col-md-6 form-group p_star" style="100 px">
                            <p>Alamat Tujuan</p>
                            <select name="alamat_tujuan" style="width 100px" id="">
                                <option value="">Pilih Kota</option>
                                <option value="padang">Padang</option>
                                <option value="pekanbaru">Pekan Baru</option>
                                <option value="jambi">Jambi</option>
                                <option value="jakarta">Jakarta</option>
                            </select>
                            <span class="placeholder" data-placeholder="Alamat"></span>
                        </div>
                        <br><br><br>
                        <div class="col-md-6 form-group p_star">
                            Alamat Detail
                            <input type="text" class="form-control" id="email" name="alamat_detail" value="">
                            <span class="placeholder" data-placeholder="Alamat Lengkap"></span>
                        </div>
                        <div class="col-md-6 form-group p_star">
                            <input type="hidden" class="form-control" id="email" name="status_pesanan" value="pending">
                            <span class="placeholder" data-placeholder="Alamat"></span>
                        </div>
                        <br>
                        <button class="button btn-primary" style="background-color: blue;" type="submit">Check Out</button>
                    </form>
                </div>
                <div class="col-lg-4">
                    <div class="order_box">
                        <h2>Your Order</h2>
                        <?php
                        $total_kuantitas = 0;
                        $total_harga = 0;
                        $project = mysqli_query($koneksi, "SELECT * FROM keranjang 
                          JOIN produk ON keranjang.id_produk=produk.id_produk 
                          JOIN user ON keranjang.id_user=user.id_user
                          WHERE user.id_user='$_SESSION[id_user]'
                          ORDER BY id_keranjang DESC");
                        while ($data = mysqli_fetch_array($project)) :
                            $total_kuantitas += $data['kuantitas'];
                            $total = $data['kuantitas'] * $data['harga'];
                            $total_harga += $data['kuantitas'] * $data['harga'];
                        ?>
                            <ul class="list">
                                <li><a href="#">
                                        <h4>Product <span>Total</span></h4>
                                    </a></li>
                                <li><a href="#"><?= $data['nama_produk'] ?> <span class="middle"><?= $data['kuantitas'] ?></span> <span class="last">Rp<?= $total ?></span></a></li>
                            </ul>
                        <?php endwhile; ?>

                        <div class="text-center">
                            <a class="button button-paypal" href="?page=pesanan/proses">Proceed Pembayaran</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Checkout Area =================-->